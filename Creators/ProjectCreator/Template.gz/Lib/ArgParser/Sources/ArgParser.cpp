/**
 * @Author: Victor Sousa <vicostudio>
 * @Date:   21/04/2018 02:06:13
 * @Email:  victor.sousa@epitech.eu
 * @Last modified by:   vicostudio
 * @Last modified time: 21/04/2018 02:07:39
 */

void fakeSymbol() {
    
}
