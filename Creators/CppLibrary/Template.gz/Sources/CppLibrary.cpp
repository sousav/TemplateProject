/**
 * @Author: Victor Sousa <vicostudio>
 * @Email:  victor.sousa@epitech.eu
 * @Date:   14/04/2018 18:09:05
 *
 * @Last modified by:   vicostudio
 * @Last modified time: 12/05/2018 17:42:10
 */


#include <CppLibrary.h>

{{project_name}}::{{project_name}}() {

}

{{project_name}}::~{{project_name}}() {

}
